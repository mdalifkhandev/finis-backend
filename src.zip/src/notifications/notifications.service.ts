import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsGateway } from './notifications.gateway';

@Injectable()
export class NotificationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly gateway: NotificationsGateway,
  ) {}

  async send(dto: {
    userId?: string;
    title: string;
    body: string;
    type?: string;
    refId?: string;
    refType?: string;
  }) {
    const notification = await this.prisma.notification.create({
      data: {
        userId: dto.userId!,
        title: dto.title,
        body: dto.body,
        type: (dto.type as any) ?? 'general',
        refId: dto.refId,
        refType: dto.refType,
      },
    });

    if (dto.userId) {
      this.gateway.sendToUser(dto.userId, notification);
    } else {
      this.gateway.broadcastAll(notification);
    }

    await this.sendExpoPush(dto.userId, dto.title, dto.body);
    return notification;
  }

  private async sendExpoPush(
    userId: string | undefined,
    title: string,
    body: string,
  ) {
    try {
      let tokens: string[] = [];

      if (userId) {
        const deviceTokens = await (this.prisma as any).deviceToken.findMany({
          where: { userId },
          select: { token: true },
        });
        tokens = deviceTokens.map((d) => d.token);
      }

      if (!tokens.length) return;

      const messages = tokens.map((token) => ({
        to: token,
        title,
        body,
        sound: 'default',
      }));

      await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify(messages),
      });
    } catch (error) {
      console.error('Expo push error:', error);
    }
  }

  async getForUser(userId: string) {
    return this.prisma.notification.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }

  async markRead(id: string) {
    return this.prisma.notification.update({
      where: { id },
      data: { isRead: true },
    });
  }

  async markAllRead(userId: string) {
    return this.prisma.notification.updateMany({
      where: { userId, isRead: false },
      data: { isRead: true },
    });
  }

  async getUnreadCount(userId: string) {
    return this.prisma.notification.count({
      where: { userId, isRead: false },
    });
  }

  async saveDeviceToken(userId: string, token: string, platform?: string) {
    return (this.prisma as any).deviceToken.upsert({
      where: { token },
      create: { userId, token, platform },
      update: { userId, platform },
    });
  }

  async removeDeviceToken(token: string) {
    return (this.prisma as any).deviceToken.delete({ where: { token } });
  }
}

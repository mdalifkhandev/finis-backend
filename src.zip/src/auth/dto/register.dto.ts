import { IsEmail, IsNotEmpty, IsString, MinLength } from 'class-validator';

export class RegisterDto {
  @IsEmail()
  email?: string;

  @IsString()
  @IsNotEmpty()
  fullName?: string;

  @IsString()
  @MinLength(6)
  password?: string;
}